#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <errno.h>
#include <pthread.h>
#

// Open the csv file and produce error
// if it couldn't be opened

double arrA[6];
double arrB[6];
int open_file(char *filename)
{
  int fd = open(filename, O_RDONLY);
  
  if (errno == EBADF){
      printf("Error in Opening File");
      exit(EXIT_FAILURE);
    }
    
    if (errno == EINTR){
      printf("File does not exist");
      exit(EXIT_FAILURE);
    }

  return fd;
}

int parse_line(char *line, char section)
{
  int student_id;
  char student_section;
  char *token;
  char *saveptr;
  char *delim = ",";

  // Student ID
  token = strtok_r(line, delim, &saveptr);
  student_id = atoi(token);

  // Student section
  token = strtok_r(NULL, delim, &saveptr);
  student_section = token[0];

  // If the student section is not same
  // as the requested section, return
  if (student_section != section) return 0;

  if (student_section == 'A'){
    int i = 0;

    while (token = strtok_r(NULL, delim, &saveptr))
    {
    arrA[i] += atoi(token);
    i++;
    }
  }
  if (student_section == 'B'){
    int j = 0;

    while (token = strtok_r(NULL, delim, &saveptr)){
    arrB[j] += atoi(token);
    j++;
    }
  }

  return 1;
  
}

void printAssgnAvg(int n, double arr[]){

    for(int i = 0;i<6;i++){
        arr[i] = arr[i]/(float)n;
        char *totalAvg;
        snprintf(totalAvg,100,"\nAverage Score for Assignment %d: %f\n", i+1 , arr[i]);
        write(STDOUT_FILENO, totalAvg, strlen(totalAvg));
    }
}

// Get the file length (number of bytes)
// to be used to print the content
int getFileLength(int fd)
{
  int file_length = (int) lseek(fd, 0, SEEK_END);
  if (file_length == -1){
    printf("Error in getting size of file");
    exit(EXIT_FAILURE);
  }

  // Go back to the start of the file
  if ((int) lseek(fd, 0, SEEK_SET) == -1){
    printf("Error in getting size of file");
    exit(EXIT_FAILURE);
  }

  return file_length;
}

// Read file from file descriptor and file length
char *readFile(int fd, int file_length)
{
  // Allocate memory for file content
  char *buf = (char *) calloc(file_length, sizeof(char));

  // Read the file
  if (read(fd, buf, file_length) == -1)
  {
    printf("Error in reading file");
    exit(EXIT_FAILURE);
  }

  return buf;
}

// Parse CSV row


// Parse the CSV table
void fileProcess(char *file_content, char section)
{
  char *saveptr;
  char *delim = "\n";
  char *line = strtok_r(file_content, delim, &saveptr);
  int header = 1;
  int count = 0;

  do {
    // Skip the initial CSV header
    if (header)
    {
      header = 0;
      continue;
    }

    // Parse the current line
    count += parse_line(line, section);
  }
  while (line = strtok_r(NULL, delim, &saveptr));
  
  if(section == 'A'){
    printAssgnAvg(count,arrA);
  }
  if(section == 'B'){
    printAssgnAvg(count,arrB);
  }
}

void* FuncSec(void * arg){
    double *result = malloc(6*sizeof(double));
    int fd = open_file("student_record.csv");
    int file_length = getFileLength(fd);
    char *file_content = readFile(fd, file_length);

    char heading[25];
    snprintf(heading,25,"\n\nSection %p:\n",arg);
    if (write(STDOUT_FILENO, heading, strlen(heading)) == -1)
    {
      char *error3 = "Error in writing to file";
        write(STDOUT_FILENO, error3, strlen(error3));
        exit(EXIT_FAILURE);
    }
    if(arg == 'A'){
      result = arrA;
    }
    if(arg == 'B'){
      result = arrB;
    }

    fileProcess(file_content, (char)arg);
    pthread_exit(result);
}

void main()
{
  // Fork the process and store child pid
  double *resA = malloc(6*sizeof(double));
  double *resB = malloc(6*sizeof(double));
  
  pthread_t threadSecA;
  pthread_t threadSecB;
  pthread_create(&threadSecA,NULL,FuncSec,(void *)'A');
  pthread_join(threadSecA,(double **) &resA);
  pthread_create(&threadSecB,NULL,FuncSec,(void *)'B');
  pthread_join(threadSecB,(double **) &resB);

  char *totalAvgHead = "\n\nTOTAL AVERAGES (Across both Sections A and B)\n\n";
  write(STDOUT_FILENO, totalAvgHead, strlen(totalAvgHead));

  for(int i = 0;i<6;i++){
    printf("\n Total Average Score for Assignment %d: %f\n", i+1 , (resA[i]+resB[i])/2);
  }  
}
