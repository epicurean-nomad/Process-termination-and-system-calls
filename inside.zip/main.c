#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <errno.h>

// Open the csv file and produce error
// if it couldn't be opened
int arr[6];

int open_file(char *filename)
{
  int fd = open(filename, O_RDONLY);
  
  if (errno == EBADF){
      printf("Error in Opening File");
      exit(EXIT_FAILURE);
    }
    
    if (errno == EINTR){
      printf("File does not exist");
      exit(EXIT_FAILURE);
    }

  return fd;
}

// Get the file length (number of bytes)
// to be used to print the content
int getFileLength(int fd)
{
  int file_length = (int) lseek(fd, 0, SEEK_END);
  if (file_length == -1){
    printf("Error in getting size of file");
    exit(EXIT_FAILURE);
  }

  // Go back to the start of the file
  if ((int) lseek(fd, 0, SEEK_SET) == -1){
    printf("Error in getting size of file");
    exit(EXIT_FAILURE);
  }

  return file_length;
}

// Read file from file descriptor and file length
char *readFile(int fd, int file_length)
{
  // Allocate memory for file content
  char *buf = (char *) calloc(file_length, sizeof(char));

  // Read the file
  if (read(fd, buf, file_length) == -1)
  {
    printf("Error in reading file");
    exit(EXIT_FAILURE);
  }

  return buf;
}

// Parse CSV row
int parse_line(char *line, char section)
{
  int student_id;
  char student_section;
  char *token;
  char *saveptr;
  char *delim = ",";

  // Student ID
  token = strtok_r(line, delim, &saveptr);
  student_id = atoi(token);

  // Student section
  token = strtok_r(NULL, delim, &saveptr);
  student_section = token[0];

  // If the student section is not same
  // as the requested section, return
  if (student_section != section) return 0;

  
  // Loop over next ints, calc sum and count
  int i = 0;

  while (token = strtok_r(NULL, delim, &saveptr))
  {
    arr[i] += atoi(token);
    i++;
  }

  return 1;
  
}

void printAssgnAvg(int n){

    for(int i = 0;i<6;i++){
        printf("\nAverage Score for Assignment %d: %f\n", i+1 , arr[i]/(float)n);
    }
}

// Parse the CSV table
void parseFile(char *file_content, char section)
{
  char *saveptr;
  char *delim = "\n";
  char *line = strtok_r(file_content, delim, &saveptr);
  int header = 1;
  int count = 0;

  do {
    // Skip the initial CSV header
    if (header)
    {
      header = 0;
      continue;
    }

    // Parse the current line
    count += parse_line(line, section);
  }
  while (line = strtok_r(NULL, delim, &saveptr));
  
  printAssgnAvg(count);
}

int main()
{
  // Fork the process and store child pid
  pid_t childPid = fork();
  switch (childPid)
  {
    case 0:
    { // Child process
      int fd = open_file("student_record.csv");
      int file_length = getFileLength(fd);
      char *file_content = readFile(fd, file_length);

      char *heading = "\n\nSection A:\n";
      if (write(STDOUT_FILENO, heading, strlen(heading)) == -1)
    {
        printf("Error in writing to file");
        exit(EXIT_FAILURE);
    }

      parseFile(file_content, 'A');

      _exit(EXIT_SUCCESS);
    }
    case -1: // Error in forking
      printf("Error in forking Parent Process");
      exit(EXIT_FAILURE);

    default:
    { // Parent process
      waitpid(childPid, NULL, 0);
      
      if(errno == ECHILD){
        exit(EXIT_FAILURE);
      }

      int fd = open_file("student_record.csv");
      int file_length = getFileLength(fd);
      char *file_content = readFile(fd, file_length);

      char *heading = "\n\nSection B:\n";
      if (write(STDOUT_FILENO, heading, strlen(heading)) == -1)
    {
        printf("Error in writing to file");
        exit(EXIT_FAILURE);
    }

      parseFile(file_content, 'B');

    }
  }

  return 0;
}